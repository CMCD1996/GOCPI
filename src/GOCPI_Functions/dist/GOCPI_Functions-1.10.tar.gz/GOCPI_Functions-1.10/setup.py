from setuptools import setup

setup(name='GOCPI_Functions',
      version='1.1',
      description='User Defined Functions for GOCPI Project',
      packages=['GOCPI_Functions'],
      author_email='connormcdowall@gmail.com',
      zip_safe=False)
